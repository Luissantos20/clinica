<?php
$conn = new mysqli("localhost", "root", "", "clinica");
$acao = $_POST['acao'] ?? $_GET['acao'];

switch ($acao) {
    case 'cadastrar':
        $tipo = $_POST['tipo_conta'];
        $nome = $_POST['nome'];
        $descricao = $_POST['descricao'];
        $valor = $_POST['valor'];
        $data = $_POST['data'];
        $status = $_POST['status'];

        $tabela = ($tipo === 'pagar') ? 'contas_a_pagar' : 'contas_a_receber';
        $data_campo = ($tipo === 'pagar') ? 'data_vencimento' : 'data_recebimento';

        $sql = "INSERT INTO $tabela (nome, descricao, valor, $data_campo, status) 
                VALUES ('$nome', '$descricao', '$valor', '$data', '$status')";
        break;

    case 'editar':
        $id = $_POST['id'];
        $tipo = $_POST['tipo_conta'];
        $nome = $_POST['nome'];
        $descricao = $_POST['descricao'];
        $valor = $_POST['valor'];
        $data = $_POST['data'];
        $status = $_POST['status'];

        $tabela = ($tipo === 'pagar') ? 'contas_a_pagar' : 'contas_a_receber';
        $data_campo = ($tipo === 'pagar') ? 'data_vencimento' : 'data_recebimento';

        // SQL para atualizar
        $sql = "UPDATE $tabela SET nome='$nome', descricao='$descricao', valor='$valor', $data_campo='$data', status='$status' WHERE id=$id";
        break;

    case 'deletar':
        $id = $_GET['id'];
        $tipo = $_GET['tipo'];
        $tabela = ($tipo === 'pagar') ? 'contas_a_pagar' : 'contas_a_receber';

        // SQL para deletar
        $sql = "DELETE FROM $tabela WHERE id=$id";
        break;
}

if ($conn->query($sql) === TRUE) {
    echo "Operação realizada com sucesso! <a href='?page=listar-conta'>Voltar</a>";
} else {
    echo "Erro: " . $conn->error;
}
$conn->close();
?>

