<h1>Salvar Paciente</h1>
<?php 
	switch ($_REQUEST['acao']) {
		case 'cadastrar':
			$nome = $_POST['nome_paciente'];
			$cpf = $_POST['cpf_paciente'];
			$email = $_POST['email_paciente'];
			$fone = $_POST['fone_paciente'];
			$data = $_POST['data_nasc_paciente'];
			$sexo = $_POST['sexo_paciente'];
			$endereco = $_POST['endereco_paciente'];

			$sql = "INSERT INTO paciente

			(nome_paciente,cpf_paciente,email_paciente, fone_paciente,data_nasc_paciente,sexo_paciente,endereco_paciente)
					VALUES
					('{$nome}','{$cpf}','{$email}','{$fone}','{$data}','{$sexo}','{$endereco}')";



			$res = $conn->query($sql);

			if($res==true) {
				print"<script>alert('Cadastrou com sucesso!');</script>";
				print"<script>location.href='?page=listar-paciente';</script>";
			}else{
				print"<script>alert('Algo deu errado!');</script>";
				print"<script>location.href='?page=listar-paciente';</script>";
			}
			break;


			case 'editar':
				$nome = $_POST['nome_paciente'];
				$cpf = $_POST['cpf_paciente'];
				$email = $_POST['email_paciente'];
				$fone = $_POST['fone_paciente'];
				$data = $_POST['data_nasc_paciente'];
				$sexo = $_POST['sexo_paciente'];
				$endereco = $_POST['endereco_paciente'];

				$sql = "UPDATE paciente SET

						nome_paciente = '{$nome}',
						cpf_paciente= '{$cpf}',
						email_paciente = '{$email}',
						fone_paciente = '{$fone}',
						data_nasc_paciente = '{$data}',
						sexo_paciente = '{$sexo}',
						endereco_paciente = '{$endereco}'

						WHERE
							id_paciente = ".$_POST["id_paciente"];

				$res = $conn->query($sql);

				if($res==true) {
					print"<script>alert('editou com sucesso!');</script>";
					print"<script>location.href='?page=listar-paciente';</script>";
				}else{
					print"<script>alert('Algo deu errado!');</script>";
					print"<script>location.href='?page=listar-paciente';</script>";
				}
				break;


				case 'excluir':

				$sql = "DELETE FROM paciente

						WHERE id_paciente = ".$_REQUEST['id_paciente'];

				$res = $conn->query($sql);

				if($res==true) {
					print"<script>alert('excluido com sucesso!');</script>";
					print"<script>location.href='?page=listar-paciente';</script>";
				}else{
					print"<script>alert('Algo deu errado!');</script>";
					print"<script>location.href='?page=listar-paciente';</script>";
				}
				break;


		}
?>