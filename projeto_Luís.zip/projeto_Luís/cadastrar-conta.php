<h1>Cadastrar Contas</h1>
<style>
        body {
            background-color: #add8e6; /* Azul claro em hexadecimal */
        }
</style>
<form action="?page=salvar-conta" method="POST">
    <input type="hidden" name="acao" value="cadastrar">

    <div class="mb-3">
        <label>Tipo de Conta</label>
        <select name="tipo_conta" class="form-control" required>
            <option value="pagar">Conta a Pagar</option>
            <option value="receber">Conta a Receber</option>
        </select>
    </div>

    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Descrição</label>
        <textarea name="descricao" class="form-control"></textarea>
    </div>

    <div class="mb-3">
        <label>Valor</label>
        <input type="number" step="0.01" name="valor" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Data</label>
        <input type="date" name="data" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Status</label>
        <select name="status" class="form-control" required>
            <option value="pendente">Pendente</option>
            <option value="pago">Pago</option>
            <option value="atrasado">Atrasado</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Salvar Conta</button>
</form>
