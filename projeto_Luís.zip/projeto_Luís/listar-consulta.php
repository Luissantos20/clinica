
<?php

include('config.php'); 

$query = "SELECT c.id_consulta, c.data_consulta, c.hora_consulta, c.descricao_consulta, 
                 m.nome_medico, p.nome_paciente
          FROM consulta c
          JOIN medico m ON c.medico_id_medico = m.id_medico
          JOIN paciente p ON c.paciente_id_paciente = p.id_paciente";

$result = $conn->query($query);

if (!$result) {
    echo "Erro na consulta: " . $conn->error;
    exit;
}
?>

<title>Listar Consultas</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
        padding: 0;
        background-color: #add8e6;
    }
    h1 {
        text-align: center;
        color: #333;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        background-color: #fff;
    }
    th, td {
        padding: 10px;
        text-align: left;
        border: 1px solid #ccc;
    }
    th {
        background-color: #f4f4f4;
    }
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }
    .container {
        max-width: 800px;
        margin: auto;
    }
    .btn {
        padding: 5px 10px;
        border: none;
        cursor: pointer;
        color: white;
    }
    .btn-success {
        background-color: #28a745;
    }
    .btn-danger {
        background-color: #dc3545;
    }
    .btn:hover {
        opacity: 0.8;
    }
</style>

<div class="container">
    <h1>Listar Consultas</h1>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Data</th>
                <th>Hora</th>
                <th>Descrição</th>
                <th>Médico</th>
                <th>Paciente</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id_consulta'] . "</td>";
                    echo "<td>" . date('d/m/Y', strtotime($row['data_consulta'])) . "</td>";
                    echo "<td>" . $row['hora_consulta'] . "</td>";
                    echo "<td>" . $row['descricao_consulta'] . "</td>";
                    echo "<td>" . $row['nome_medico'] . "</td>";
                    echo "<td>" . $row['nome_paciente'] . "</td>";
                    
                    echo "<td>
                        <a href='?page=editar-consulta&id_consulta=" . $row['id_consulta'] . "' class='btn btn-success'>Editar</a>
                        <a href='?page=salvar-consulta&acao=excluir&id_consulta=" . $row['id_consulta'] . "' 
                            class='btn btn-danger' onclick=\"return confirm('Tem certeza que deseja excluir?')\">Excluir</a>
                    </td>";

                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>Nenhuma consulta encontrada.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>
