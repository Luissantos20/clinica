<h1>Salvar Consulta</h1>
<?php 
switch ($_REQUEST['acao']) {
    case 'cadastrar':
        $data_consulta = $_POST['data_consulta'];
        $hora_consulta = $_POST['hora_consulta'];
        $descricao_consulta = $_POST['descricao_consulta'];
        $medico_id_medico = $_POST['medico_id_medico'];
        $paciente_id_paciente = $_POST['paciente_id_paciente'];

        $sql = "INSERT INTO consulta
                (data_consulta, hora_consulta, descricao_consulta, medico_id_medico, paciente_id_paciente)
                VALUES
                ('{$data_consulta}', '{$hora_consulta}', '{$descricao_consulta}', '{$medico_id_medico}', '{$paciente_id_paciente}')";

        $res = $conn->query($sql);

        if($res == true) {
            print"<script>alert('Consulta cadastrada com sucesso!');</script>";
            print"<script>location.href='?page=listar-consulta';</script>"; // Redireciona para listar consultas
        } else {
            print"<script>alert('Algo deu errado!');</script>";
            print"<script>location.href='?page=listar-consulta';</script>";
        }
        break;

    case 'editar':
        $data_consulta = $_POST['data_consulta'];
        $hora_consulta = $_POST['hora_consulta'];
        $descricao_consulta = $_POST['descricao_consulta'];
        $medico_id_medico = $_POST['medico_id_medico'];
        $paciente_id_paciente = $_POST['paciente_id_paciente'];
        $id_consulta = $_POST['id_consulta'];

        $sql = "UPDATE consulta SET
                data_consulta = '{$data_consulta}',
                hora_consulta = '{$hora_consulta}',
                descricao_consulta = '{$descricao_consulta}',
                medico_id_medico = '{$medico_id_medico}',
                paciente_id_paciente = '{$paciente_id_paciente}'
                WHERE id_consulta = {$id_consulta}";

        $res = $conn->query($sql);

        if($res == true) {
            print"<script>alert('Consulta alterada com sucesso!');</script>";
            print"<script>location.href='?page=listar-consulta';</script>"; // Redireciona para listar consultas
        } else {
            print"<script>alert('Algo deu errado!');</script>";
            print"<script>location.href='?page=listar-consulta';</script>";
        }
        break;

        case 'excluir':
            $id_consulta = $_REQUEST['id_consulta'];

            $sql_relatorio = "DELETE FROM relatorio_medico WHERE id_consulta = {$id_consulta}";
            $conn->query($sql_relatorio);

            $sql_consulta = "DELETE FROM consulta WHERE id_consulta = {$id_consulta}";
            $res = $conn->query($sql_consulta);

            if($res == true) {
                print"<script>alert('Consulta excluída com sucesso!');</script>";
                print"<script>location.href='?page=listar-consulta';</script>"; // Redireciona para listar consultas
            } else {
                print"<script>alert('Algo deu errado!');</script>";
                print"<script>location.href='?page=listar-consulta';</script>";
            }
            break;
}
?>
