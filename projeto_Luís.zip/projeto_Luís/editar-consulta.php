<h1>Editar Consulta</h1>
<?php
$sql = "SELECT * FROM consulta WHERE id_consulta = " . $_REQUEST['id_consulta'];
$res = $conn->query($sql);
$row = $res->fetch_object();
?>

<form action="?page=salvar-consulta" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id_consulta" value="<?php echo $row->id_consulta; ?>">

    <div class="mb-3">
        <label>Data da Consulta</label>
        <input type="date" name="data_consulta" class="form-control" value="<?php echo $row->data_consulta; ?>" required>
    </div>

    <div class="mb-3">
        <label>Hora da Consulta</label>
        <input type="time" name="hora_consulta" class="form-control" value="<?php echo $row->hora_consulta; ?>" required>
    </div>

    <div class="mb-3">
        <label>Descrição da Consulta</label>
        <textarea name="descricao_consulta" class="form-control" required><?php echo $row->descricao_consulta; ?></textarea>
    </div>

    <div class="mb-3">
        <label>Médico</label>
        <select name="medico_id_medico" class="form-control" required>
            <option value="">Selecione um Médico</option>
            <?php
            $sql = "SELECT * FROM medico";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($rowMedico = $result->fetch_assoc()) {
                    // Marca o médico como selecionado se ele for o atual
                    $selected = ($rowMedico['id_medico'] == $row->medico_id_medico) ? "selected" : "";
                    echo "<option value='" . $rowMedico['id_medico'] . "' $selected>" . $rowMedico['nome_medico'] . "</option>";
                }
            } else {
                echo "<option value=''>Nenhum médico encontrado</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Paciente</label>
        <select name="paciente_id_paciente" class="form-control" required>
            <option value="">Selecione um Paciente</option>
            <?php
            $sql = "SELECT * FROM paciente";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($rowPaciente = $result->fetch_assoc()) {
                    // Marca o paciente como selecionado se ele for o atual
                    $selected = ($rowPaciente['id_paciente'] == $row->paciente_id_paciente) ? "selected" : "";
                    echo "<option value='" . $rowPaciente['id_paciente'] . "' $selected>" . $rowPaciente['nome_paciente'] . "</option>";
                }
            } else {
                echo "<option value=''>Nenhum paciente encontrado</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <button type="submit" class="btn btn-success">Salvar Alterações</button>
    </div>
</form>
