<h1>Cadastrar Consulta</h1>
<style>
        body {
            background-color: #add8e6; /* Azul claro em hexadecimal */
        }
</style>
<form action="?page=salvar-consulta" method="POST">
    <input type="hidden" name="acao" value="cadastrar">
    
    <div class="mb-3">
        <label>Data da Consulta</label>
        <input type="date" name="data_consulta" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Hora da Consulta</label>
        <input type="time" name="hora_consulta" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Descrição da Consulta</label>
        <textarea name="descricao_consulta" class="form-control" required></textarea>
    </div>

    <div class="mb-3">
        <label>Médico</label>
        <select name="medico_id_medico" class="form-control" required>
            <option value="">Selecione um Médico</option>
            <?php
            include('config.php');

            $sql = "SELECT * FROM medico";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id_medico'] . "'>" . htmlspecialchars($row['nome_medico'], ENT_QUOTES, 'UTF-8') . "</option>";
                }
            } else {
                echo "<option value=''>Nenhum médico encontrado</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <label>Paciente</label>
        <select name="paciente_id_paciente" class="form-control" required>
            <option value="">Selecione um Paciente</option>
            <?php
            $sql = "SELECT * FROM paciente";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id_paciente'] . "'>" . htmlspecialchars($row['nome_paciente'], ENT_QUOTES, 'UTF-8') . "</option>";
                }
            } else {
                echo "<option value=''>Nenhum paciente encontrado</option>";
            }
            ?>
        </select>
    </div>

    <div class="mb-3">
        <button type="submit" class="btn btn-success">Cadastrar Consulta</button>
    </div>
</form>
