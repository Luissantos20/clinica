<h2>Contas a Pagar</h2> 
<style>
        body {
            background-color: #add8e6; /* Azul claro em hexadecimal */
        }
</style>     
<table class="table">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Descrição</th>
        <th>Valor</th>
        <th>Data de Vencimento</th>
        <th>Status</th>
        <th>Ações</th>
    </tr>
    <?php
    $result = $conn->query("SELECT * FROM contas_a_pagar");
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['nome']}</td>
                <td>{$row['descricao']}</td>
                <td>{$row['valor']}</td>
                <td>{$row['data_vencimento']}</td>
                <td>{$row['status']}</td>
                <td>

                    <a href='?page=editar-conta&id={$row['id']}&tipo=pagar'>Editar</a> | 
                    <a href='?page=salvar-conta&acao=deletar&id={$row['id']}&tipo=pagar'>Deletar</a>

                </td>
            </tr>";
    }
    ?>
</table>

<h2>Contas a Receber</h2>
<table class="table">
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Descrição</th>
        <th>Valor</th>
        <th>Data de Recebimento</th>
        <th>Status</th>
        <th>Ações</th>
    </tr>
    <?php
    $result = $conn->query("SELECT * FROM contas_a_receber");
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['nome']}</td>
                <td>{$row['descricao']}</td>
                <td>{$row['valor']}</td>
                <td>{$row['data_recebimento']}</td>
                <td>{$row['status']}</td>
                <td>
                    <a href='?page=editar-conta&id={$row['id']}&tipo=receber'>Editar</a> | 
                    <a href='?page=salvar-conta&acao=deletar&id={$row['id']}&tipo=receber'>Deletar</a>
                </td>
            </tr>";
    }
    ?>
</table>
