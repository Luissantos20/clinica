<h1>Editar Conta</h1>

<?php
$conn = new mysqli("localhost", "root", "", "clinica");
$id = $_GET['id'];
$tipo = $_GET['tipo'];

$tabela = ($tipo === 'pagar') ? 'contas_a_pagar' : 'contas_a_receber';
$data_campo = ($tipo === 'pagar') ? 'data_vencimento' : 'data_recebimento';

$sql = "SELECT * FROM $tabela WHERE id = $id";
$result = $conn->query($sql);
$conta = $result->fetch_assoc();
?>

<form action="?page=salvar-conta" method="POST">
    <input type="hidden" name="acao" value="editar">
    <input type="hidden" name="id" value="<?php echo $conta['id']; ?>">
    <input type="hidden" name="tipo_conta" value="<?php echo $tipo; ?>">

    <div class="mb-3">
        <label>Nome</label>
        <input type="text" name="nome" class="form-control" value="<?php echo $conta['nome']; ?>" required>
    </div>

    <div class="mb-3">
        <label>Descrição</label>
        <textarea name="descricao" class="form-control" required><?php echo $conta['descricao']; ?></textarea>
    </div>

    <div class="mb-3">
        <label>Valor</label>
        <input type="number" step="0.01" name="valor" class="form-control" value="<?php echo $conta['valor']; ?>" required>
    </div>

    <div class="mb-3">
        <label>Data</label>
        <input type="date" name="data" class="form-control" value="<?php echo $conta[$data_campo]; ?>" required>
    </div>

    <div class="mb-3">
        <label>Status</label>
        <select name="status" class="form-control" required>
            <option value="pendente" <?php if($conta['status'] == 'pendente') echo 'selected'; ?>>Pendente</option>
            <option value="pago" <?php if($conta['status'] == 'pago') echo 'selected'; ?>>Pago</option>
            <option value="atrasado" <?php if($conta['status'] == 'atrasado') echo 'selected'; ?>>Atrasado</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Salvar Conta</button>
</form>

<?php $conn->close(); ?>

